package Start;

public class Ascii {
public static void main(String[] args) {
	String s = "Kartik";
	char [] i = s.toCharArray();
	
	
	for(int a : i) {
		System.out.println(a);
	}
}
}
