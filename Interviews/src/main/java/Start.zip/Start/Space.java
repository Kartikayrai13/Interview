package Start;

public class Space {
public static void main(String[] args) {
	String s = "N eeraj";
	if(s.contains(" ")) {
	System.out.println("null"+" "+"Please Enter the name without spaces");
}else {
	System.out.println(s);
}
}
}
