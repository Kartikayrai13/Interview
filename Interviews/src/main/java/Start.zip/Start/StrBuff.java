package Start;

public class StrBuff {
	public static void main(String[] args) {
		String str = "Hello world of good poeople";
		StringBuffer sf = new StringBuffer();
		sf.append(str);
		sf.reverse();
		System.out.println(sf);
	}
	

}
