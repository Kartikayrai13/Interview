package Start;

public class Count {

	public static void main(String[] args) {
		String str = "Hello world of good people";

		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			count++;
		}
		System.out.println(count);

	}
}
