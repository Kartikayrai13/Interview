package Collections;

import java.util.ArrayList;

public class HashCode1 {
	public static void main(String[] args) {

		ArrayList a = new ArrayList();
		a.add(1);
		a.add(2);
		a.hashCode();
		System.out.println(a.hashCode());
	}
}