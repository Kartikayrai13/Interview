package Collections;

import java.util.HashSet;

public class HashSet1 {
public static void main(String[] args) {
	HashSet s = new HashSet();
	s.add(23);
	s.add(45);
	s.add(10);
	s.add(9);
	s.add(34);
	s.add(76);
	s.add(39);
	System.out.println(s);
}
}
